MySQL Server & Workbench Setup (Windows) - https://www.youtube.com/watch?v=u96rVINbAUI

MySQL Server & Workbench Setup (Mac) - https://www.youtube.com/watch?v=6FvvWhiZyDY&t=24s
