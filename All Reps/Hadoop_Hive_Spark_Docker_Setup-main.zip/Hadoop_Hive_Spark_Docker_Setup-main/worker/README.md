# Spark worker

See [big-data-europe/docker-spark README](https://github.com/big-data-europe/docker-spark).